[app]
icon.filename = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/presplash.jpg
android.presplash_color = #000000
title = Football Arena
package.name = footballarena
package.domain = org.fomc
source.dir = .
source.include_exts = py,ogg,txt,json,ttf,png
version = 0.9
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
