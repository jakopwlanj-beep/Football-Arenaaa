[app]
title = Football Arena
package.name = footballarena
package.domain = org.fomc
source.dir = .
source.include_exts = py,ogg,txt,json,ttf
version = 0.8
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
