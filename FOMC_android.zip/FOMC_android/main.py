# -*- coding: utf-8 -*-
"""
FOOTBALL ARENA — футбольные мини-игры на Python (pygame)
Запуск:  python football_arena.py   (pip install pygame)
"""
import pygame, sys, json, random, math, os, time
from functools import lru_cache

# ============================================================
W, H = 960, 540
S = 0.5
FULLSCREEN = True
SHOW_FPS = True
FADE = True          # плавное затемнение при смене экрана (на слабых устройствах отключается само)
FADE_START = 150     # начальная яркость затемнения (0..255), раньше было 255
FADE_SPEED = 1100    # скорость затухания (раньше 700) -> ~0.14 с вместо ~0.36 с
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Сохранение лежит ВНЕ папки приложения: на Android папка приложения стирается при
# каждом обновлении APK, а ANDROID_PRIVATE переживает обновления.
SAVE_DIR = os.environ.get("ANDROID_PRIVATE") or BASE_DIR
SAVE = os.path.join(SAVE_DIR, "football_stats.json")

# ============================================================
#  ДАННЫЕ ИЗ ФАЙЛОВ  (папка data рядом с игрой)
#    data/quiz.txt         — вопросы викторины
#    data/comparisons.txt  — пары для «Сравнений»
#    data/teams.txt        — команды для симуляции матчей
#  Одна запись = одна строка, поля разделены знаком «|». Строки с # — комментарии.
#  Если файла нет или он сломан — игра берёт встроенные данные и не падает.
# ============================================================
DATA_DIR = os.path.join(BASE_DIR, "data")
DATA_WARNINGS = []
DATA_SOURCES = {}          # какой файл реально подхватился: имя -> путь (или None, если взяты встроенные данные)


def _warn(msg):
    DATA_WARNINGS.append(msg)
    print("[data]", msg)


def _read_lines(filename):
    """Строки файла data/<filename> (или лежащего рядом с игрой). None — файла нет."""
    path = None
    for folder in (DATA_DIR, BASE_DIR):
        cand = os.path.join(folder, filename)
        if os.path.isfile(cand):
            path = cand
            break
    if path is None:
        return None
    DATA_SOURCES[filename] = path
    for enc in ("utf-8-sig", "cp1251"):                 # utf-8 (с BOM или без) или «блокнот» Windows
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read().splitlines()
        except UnicodeDecodeError:
            continue
        except OSError:
            return None
    return None


def _records(filename, n_fields):
    """Список (номер_строки, [поля]) из файла; None — файла нет."""
    lines = _read_lines(filename)
    if lines is None:
        _warn(f"Файл {filename} не найден — использую встроенные данные")
        return None
    out = []
    for no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) != n_fields or not all(parts):
            _warn(f"{filename}, строка {no}: нужно {n_fields} непустых поля(ей) через «|»")
            continue
        out.append((no, parts))
    return out


def _finish(filename, items, default, minimum):
    if len(items) < minimum:
        DATA_SOURCES[filename] = None
        if items or os.path.exists(os.path.join(DATA_DIR, filename)) or os.path.exists(os.path.join(BASE_DIR, filename)):
            _warn(f"{filename}: мало корректных записей (нужно минимум {minimum}) — использую встроенные данные")
        return default
    return items


def load_quiz(default):
    recs = _records("quiz.txt", 4)          # вопрос | правильный | неправильный 1 | неправильный 2
    items = []
    for no, (q, right, w1, w2) in recs or []:
        if len({right, w1, w2}) < 3:
            _warn(f"quiz.txt, строка {no}: варианты ответа должны отличаться")
            continue
        items.append((q, [right, w1, w2], 0))   # правильный — первый, при показе ответы перемешиваются
    return _finish("quiz.txt", items, default, 1)


def load_pairs(default):
    recs = _records("comparisons.txt", 3)   # категория | вариант 1 | вариант 2
    items = [(c, a, b) for _, (c, a, b) in recs or []]
    return _finish("comparisons.txt", items, default, 1)


NO_LEAGUE = "ОСТАЛЬНОЙ МИР"     # сюда попадают команды, записанные выше первой строки [Лига]


def load_leagues(default):
    """data/teams.txt: разделы [Название лиги], под каждым — строки «Команда | рейтинг».
    Возвращает [(название лиги, [(команда, рейтинг), ...]), ...] в том порядке, как в файле."""
    lines = _read_lines("teams.txt")
    if lines is None:
        _warn("Файл teams.txt не найден — использую встроенные данные")
        return default
    leagues, order = {}, []
    cur, seen, total = NO_LEAGUE, set(), 0
    for no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            if not line.endswith("]") or not line[1:-1].strip():
                _warn(f"teams.txt, строка {no}: название лиги пишется в скобках, например [АПЛ]")
                cur = None                              # команды до следующего [раздела] пропускаем
                continue
            cur = line[1:-1].strip()
            if cur not in leagues:
                leagues[cur] = []
                order.append(cur)
            continue
        if cur is None:
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) != 2 or not all(parts):
            _warn(f"teams.txt, строка {no}: нужно «Название | рейтинг»")
            continue
        name, rating = parts
        if not rating.isdigit() or not 1 <= int(rating) <= 100:
            _warn(f"teams.txt, строка {no}: рейтинг должен быть числом от 1 до 100")
            continue
        if name in seen:
            _warn(f"teams.txt, строка {no}: команда «{name}» уже есть")
            continue
        seen.add(name)
        if cur not in leagues:
            leagues[cur] = []
            order.append(cur)
        leagues[cur].append((name, int(rating)))
        total += 1
    result = []
    for name in order:
        if leagues[name]:
            result.append((name, leagues[name]))
        else:
            _warn(f"teams.txt: лига [{name}] пуста — пропущена")
    if total < 2:
        DATA_SOURCES["teams.txt"] = None
        _warn("teams.txt: нужно минимум 2 команды — использую встроенные данные")
        return default
    return result


def ru_plural(n, one, few, many):
    n10, n100 = n % 10, n % 100
    if n10 == 1 and n100 != 11:
        return one
    if 2 <= n10 <= 4 and not 12 <= n100 <= 14:
        return few
    return many


def short(s, n):
    return s if len(s) <= n else s[:n - 1] + "…"

SND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sounds")
MUSIC_FILE = "81cebf7e45fdef7.ogg"     # фоновая музыка (лежит в папке sounds)
MUSIC_VOLUME = 0.5                     # 0.0 .. 1.0

pygame.init()

def _make_screen():
    base = (pygame.FULLSCREEN if FULLSCREEN else 0)
    flags = getattr(pygame, "SCALED", 0) | base
    for kw, fl in (({"vsync": 1}, flags), ({}, flags), ({}, base)):
        try:
            return pygame.display.set_mode((W, H), fl, **kw)
        except (TypeError, pygame.error):
            continue
    return pygame.display.set_mode((W, H))

screen = _make_screen()
pygame.display.set_caption("Football Arena")
clock = pygame.time.Clock()

WHITE = (255, 255, 255); GREEN = (30, 160, 90); BLUE = (40, 110, 210)
RED = (215, 55, 60); GOLD = (245, 190, 40); PURPLE = (130, 70, 200)
GRAY = (90, 100, 110); DARK = (10, 25, 20)

_FINGERDOWN = getattr(pygame, "FINGERDOWN", -1)


# ---------------------------------------------------------------- helpers
def sc(v):
    return int(v * S)


_fc = {}
_FONT_LIST = "segoeui,arial,dejavusans,liberationsans,verdana,helvetica"


def font(design_size, bold=True):
    """design_size — размер в дизайн-координатах (1920×1080). Возвращает шрифт в пикселях экрана."""
    px = max(6, int(design_size * S))
    k = (px, bold)
    if k not in _fc:
        bundled = os.path.join(BASE_DIR, "fonts", "DejaVuSans-Bold.ttf")
        try:
            f = pygame.font.Font(bundled, px)
        except Exception:
            try:
                f = pygame.font.SysFont(_FONT_LIST, px, bold=bold)
            except Exception:
                f = pygame.font.Font(None, px)
        _fc[k] = f
    return _fc[k]


@lru_cache(maxsize=800)
def _render_text_cached(s, design_size, color, bold, shadow):
    """Возвращает (поверхность, (w, h)) где w,h — размер текста без тени."""
    f = font(design_size, bold)
    img = f.render(s, True, color)
    w, h = img.get_size()
    if not shadow:
        return img, (w, h)
    combined = pygame.Surface((w + 3, h + 3), pygame.SRCALPHA)
    sh = f.render(s, True, (0, 0, 0))
    sh.set_alpha(110)
    combined.blit(sh, (3, 3))
    combined.blit(img, (0, 0))
    return combined.convert_alpha(), (w, h)


def text(surf, s, design_size, color, pos, anchor="center", bold=True, shadow=True):
    if len(color) == 4:
        color = color[:3]
    combined, _ = _render_text_cached(s, int(design_size), color, bold, shadow)
    px, py = sc(pos[0]), sc(pos[1])
    r = combined.get_rect(**{anchor: (px, py)})
    surf.blit(combined, r.topleft)
    return r


@lru_cache(maxsize=500)
def _make_panel(w, h, color, radius, border, bw):
    s = pygame.Surface((max(1, w), max(1, h)), pygame.SRCALPHA)
    pygame.draw.rect(s, color, s.get_rect(), border_radius=max(0, radius))
    if border:
        pygame.draw.rect(s, border, s.get_rect(), max(1, bw), border_radius=max(0, radius))
    return s.convert_alpha()


def panel(surf, rect, color, radius=24, border=None, bw=3):
    """rect и radius — в дизайн-координатах."""
    x, y, w, h = rect[0], rect[1], rect[2], rect[3]
    sx, sy, sw, sh = sc(x), sc(y), max(1, sc(w)), max(1, sc(h))
    sr = max(1, sc(radius))
    sbw = max(1, sc(bw))
    color = color if len(color) == 4 else (*color, 255)
    if border is not None and len(border) == 3:
        border = (*border, 255)
    s = _make_panel(sw, sh, color, sr, border, sbw)
    surf.blit(s, (sx, sy))


@lru_cache(maxsize=200)
def wrap(s, design_size, max_design_w):
    lines, cur = [], ""
    f = font(design_size)
    max_px = sc(max_design_w)
    for word in s.split():
        test = (cur + " " + word).strip()
        if f.size(test)[0] <= max_px:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return tuple(lines)


def ease(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def get_click_pos(e):
    if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
        return e.pos
    if e.type == _FINGERDOWN:
        return (int(e.x * W), int(e.y * H))
    return None


# ---------------------------------------------------------------- скины магазина
KEEPER_SKINS = {
    "k_default": dict(name="Классика", price=0, jersey=(255, 165, 20), sleeve=(255, 150, 0),
                      pants=(30, 30, 45), cap=(40, 40, 40)),
    "k_blue": dict(name="Синяя молния", price=25, jersey=(50, 130, 235), sleeve=(30, 100, 200),
                   pants=(15, 30, 80), cap=(20, 40, 90)),
    "k_gold": dict(name="Золотой страж", price=50, jersey=(245, 200, 60), sleeve=(210, 160, 30),
                   pants=(70, 50, 10), cap=(100, 70, 10)),
}
BALL_SKINS = {
    "b_default": dict(name="Классика", price=0, base=(250, 250, 250), dark=(25, 25, 30), edge=(40, 40, 45)),
    "b_fire": dict(name="Огненный", price=20, base=(255, 140, 50), dark=(110, 25, 10), edge=(90, 25, 10)),
    "b_gold": dict(name="Золотой", price=40, base=(250, 205, 70), dark=(140, 95, 10), edge=(120, 80, 5)),
}


ACH_REWARD = 30
ACHIEVEMENTS = {
    "goals5": ("Снайпер", "Забей все 5 пенальти в серии"),
    "saves5": ("Железная стена", "Отбей все 5 ударов в серии за вратаря"),
    "quiz_clean": ("Знаток футбола", "Пройди все уровни викторины без единой ошибки"),
}


def draw_ball(surf, pos, r, rot=0.0, skin=None):
    skin = skin or BALL_SKINS["b_default"]
    x, y = sc(pos[0]), sc(pos[1])
    r = max(4, sc(r))
    dark = skin["dark"]
    pygame.draw.circle(surf, skin["base"], (x, y), r)
    pts = [(x + math.cos(rot + i * 2 * math.pi / 5) * r * 0.36,
            y + math.sin(rot + i * 2 * math.pi / 5) * r * 0.36) for i in range(5)]
    pygame.draw.polygon(surf, dark, pts)
    for i in range(5):
        a = rot + i * 2 * math.pi / 5
        p1 = (x + math.cos(a) * r * 0.36, y + math.sin(a) * r * 0.36)
        p2 = (x + math.cos(a) * r * 0.75, y + math.sin(a) * r * 0.75)
        pygame.draw.line(surf, dark, p1, p2, max(1, int(r * 0.07)))
        pygame.draw.circle(surf, dark, p2, max(2, int(r * 0.17)))
    pygame.draw.circle(surf, skin["edge"], (x, y), r, max(1, int(r * 0.06)))


def draw_coin(surf, pos, r):
    """Монета, нарисованная кодом (эмодзи в шрифтах pygame обычно не отображаются)."""
    x, y = sc(pos[0]), sc(pos[1])
    r = max(4, sc(r))
    pygame.draw.circle(surf, (190, 130, 10), (x, y), r)
    pygame.draw.circle(surf, GOLD, (x, y), r - max(1, r // 8))
    pygame.draw.circle(surf, (255, 228, 130), (x, y), int(r * 0.62), max(1, r // 9))
    pygame.draw.line(surf, (190, 130, 10), (x, y - int(r * 0.35)), (x, y + int(r * 0.35)), max(2, r // 7))


def draw_star(surf, pos, r, color):
    x, y = sc(pos[0]), sc(pos[1])
    r = max(4, sc(r))
    pts = []
    for i in range(10):
        a = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.42
        pts.append((x + math.cos(a) * rr, y + math.sin(a) * rr))
    pygame.draw.polygon(surf, color, pts)


_music_started = False


def find_music():
    """Путь к файлу музыки. Если нужного имени нет — берёт первый аудиофайл из папки sounds."""
    path = os.path.join(SND_DIR, MUSIC_FILE)
    if os.path.isfile(path):
        return path
    try:
        for f in sorted(os.listdir(SND_DIR)):
            if f.lower().endswith((".ogg", ".mp3", ".wav", ".flac")):
                return os.path.join(SND_DIR, f)
    except OSError:
        pass
    return None


def music_set(on):
    """Включает/выключает фоновую музыку. Без файла или звуковой карты игра просто молчит."""
    global _music_started
    try:
        if on:
            if not _music_started:
                path = find_music()
                if path is None:
                    return
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(MUSIC_VOLUME)
                pygame.mixer.music.play(-1)          # -1 = по кругу
                _music_started = True
            else:
                pygame.mixer.music.set_volume(MUSIC_VOLUME)
                pygame.mixer.music.unpause()
                if not pygame.mixer.music.get_busy():      # если пауза не сохранилась — запускаем заново
                    pygame.mixer.music.play(-1)
        elif _music_started:
            pygame.mixer.music.set_volume(0)               # тишина даже там, где pause() капризничает
            pygame.mixer.music.pause()
    except Exception:
        pass


def poisson(lam):
    L = math.exp(-lam); k, p = 0, 1.0
    while True:
        p *= random.random()
        if p <= L: return k
        k += 1


def make_bg():
    bg = pygame.Surface((W, H))
    for y in range(H):
        t = y / H
        pygame.draw.line(bg, (int(6 + 10 * t), int(38 + 52 * t), int(26 + 22 * t)), (0, y), (W, y))
    st = pygame.Surface((W, H), pygame.SRCALPHA)
    for i in range(0, W, 80):
        if (i // 80) % 2 == 0:
            pygame.draw.rect(st, (255, 255, 255, 10), (i, 0, 80, H))
    line = (255, 255, 255, 26)
    pygame.draw.circle(st, line, (W // 2, H // 2), 115, 3)
    pygame.draw.line(st, line, (W // 2, 0), (W // 2, H), 3)
    pygame.draw.rect(st, line, (20, 20, W - 40, H - 40), 3, border_radius=6)
    bg.blit(st, (0, 0))
    return bg.convert()


BG = make_bg()
GLOW = pygame.Surface((30, 30), pygame.SRCALPHA)
for rr in range(15, 0, -1):
    pygame.draw.circle(GLOW, (255, 255, 255, int(70 * (1 - rr / 15) ** 2)), (15, 15), rr)
GLOW = GLOW.convert_alpha()
PARTS = [[random.uniform(0, W), random.uniform(0, H), random.uniform(5, 20), random.uniform(0.4, 1.6)]
         for _ in range(8)]
FADE_SURF = pygame.Surface((W, H)).convert()
FADE_SURF.fill((0, 0, 0))


def draw_particles(surf, dt):
    for p in PARTS:
        p[1] -= p[2] * dt
        p[0] += math.sin(pygame.time.get_ticks() / 1500 + p[3] * 5) * 4 * dt
        if p[1] < -20:
            p[1] = H + 20
            p[0] = random.uniform(0, W)
        surf.blit(GLOW, (int(p[0]), int(p[1])))


# ---------------------------------------------------------------- виджеты
class Button:
    def __init__(self, rect, label, color=GREEN, size=44):
        self.rect = pygame.Rect(sc(rect[0]), sc(rect[1]), sc(rect[2]), sc(rect[3]))
        self.label, self.color, self.size, self.h = label, color, size, 0.0
        self.enabled = True

    def hit(self, pos):
        return self.enabled and self.rect.collidepoint(pos)

    def draw(self, surf):
        hov = self.enabled and self.rect.collidepoint(pygame.mouse.get_pos())
        self.h += ((1.0 if hov else 0.0) - self.h) * 0.25
        r = self.rect.inflate(int(10 * self.h), int(5 * self.h))
        pygame.draw.rect(surf, (15, 20, 18), r.move(0, 4), border_radius=12)
        base = self.color if self.enabled else GRAY
        c = tuple(min(255, int(v + 45 * self.h)) for v in base)
        pygame.draw.rect(surf, c, r, border_radius=12)
        pygame.draw.rect(surf, WHITE, r, 2, border_radius=12)
        text(surf, self.label, self.size, WHITE,
             (self.rect.x / S + self.rect.w / (2 * S),
              self.rect.y / S + self.rect.h / (2 * S)))


class BackButton:
    def __init__(self, app, target=None, label="В МЕНЮ"):
        self.app, self.target, self.label = app, target, label
        self.rect = pygame.Rect(sc(30), sc(30), sc(200), sc(76))
        self.h = 0.0

    def handle(self, e):
        p = get_click_pos(e)
        if p is not None and self.rect.collidepoint(p):
            self.app.go(self.target(self.app) if self.target else Menu(self.app))
            return True
        return False

    def draw(self, surf):
        hov = self.rect.collidepoint(pygame.mouse.get_pos())
        self.h += ((1.0 if hov else 0.0) - self.h) * 0.25
        base = (int(60 + 50 * self.h), int(80 + 60 * self.h), int(100 + 60 * self.h))
        pygame.draw.rect(surf, (15, 20, 18), self.rect.move(0, 3), border_radius=10)
        pygame.draw.rect(surf, base, self.rect, border_radius=10)
        pygame.draw.rect(surf, WHITE, self.rect, 2, border_radius=10)
        text(surf, self.label, 30, WHITE,
             (self.rect.x / S + self.rect.w / (2 * S),
              self.rect.y / S + self.rect.h / (2 * S)), shadow=False)


# ---------------------------------------------------------------- статы
DEFAULT_STATS = {"penalties_scored": 0, "penalties_saved": 0, "matches": 0, "quiz_levels": 0,
                 "comparisons": 0, "coins": 0,
                 "owned": ["k_default", "b_default"], "keeper_skin": "k_default",
                 "ball_skin": "b_default", "last_daily": 0, "achievements": [], "music_on": True,
                 "quiz_progress": 0, "quiz_clean": True}


def load_stats():
    st = json.loads(json.dumps(DEFAULT_STATS))       # глубокая копия (там есть список)
    try:
        with open(SAVE, "r", encoding="utf-8") as f:
            data = json.load(f)
        st.update(data)
        if "quiz_progress" not in data:                # старое сохранение: продолжаем с пройденных уровней
            ql = int(data.get("quiz_levels", 0) or 0)
            st["quiz_progress"] = ql if ql < len(QUIZ) else 0
            st["quiz_clean"] = st["quiz_progress"] == 0   # про ошибки в прошлом заходе неизвестно
    except Exception:
        pass
    if not isinstance(st["owned"], list):
        st["owned"] = []
    st["music_on"] = bool(st["music_on"])
    st["quiz_clean"] = bool(st["quiz_clean"])
    try:
        qp = int(st["quiz_progress"])
    except (TypeError, ValueError):
        qp = 0
    st["quiz_progress"] = qp if 0 <= qp < len(QUIZ) else 0
    if not isinstance(st["achievements"], list):
        st["achievements"] = []
    for did in ("k_default", "b_default"):
        if did not in st["owned"]:
            st["owned"].append(did)
    for key, skins, did in (("keeper_skin", KEEPER_SKINS, "k_default"), ("ball_skin", BALL_SKINS, "b_default")):
        if st[key] not in skins or st[key] not in st["owned"]:
            st[key] = did
    return st


class App:
    def __init__(self):
        self.stats = load_stats()
        self.fade = 0
        self.toast_n, self.toast_t = 0, 0.0
        self.ach_name, self.ach_t = "", 0.0
        self.scene = None
        self.go(Menu(self))

    def go(self, scene):
        self.scene = scene
        self.fade = FADE_START if FADE else 0

    DAILY_COINS = 15
    DAILY_COOLDOWN = 24 * 3600

    def daily_remaining(self):
        """Сколько секунд до следующего бонуса (0 — можно забирать)."""
        last = self.stats["last_daily"]
        if not last:
            return 0
        rem = last + self.DAILY_COOLDOWN - time.time()
        return max(0, min(self.DAILY_COOLDOWN, rem))   # min защищает от перевода часов назад

    def claim_daily(self):
        if self.daily_remaining() > 0:
            return False
        self.stats["last_daily"] = time.time()
        self.add_coins(self.DAILY_COINS)
        self.save()
        return True

    def unlock(self, aid):
        """Выдаёт достижение один раз: +ACH_REWARD монет и баннер."""
        if aid in self.stats["achievements"]:
            return False
        self.stats["achievements"].append(aid)
        self.add_coins(ACH_REWARD)
        self.ach_name, self.ach_t = ACHIEVEMENTS[aid][0], 3.2
        self.save()
        return True

    def add_coins(self, n):
        """Начисляет монеты и показывает «+N». Сохранение делает вызывающий код (app.save())."""
        self.stats["coins"] += n
        self.toast_n, self.toast_t = n, 1.5

    def save(self):
        try:
            with open(SAVE, "w", encoding="utf-8") as f:
                json.dump(self.stats, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


def quit_game():
    pygame.quit()
    sys.exit()


# ---------------------------------------------------------------- меню
class Menu:
    def __init__(self, app):
        self.app, self.t = app, 0.0
        self.input_lock = 0.30
        defs = [("СЕРИЯ ПЕНАЛЬТИ", GREEN, Penalty), ("СИМУЛЯЦИЯ МАТЧЕЙ", BLUE, Match),
                ("ВИКТОРИНА", PURPLE, Quiz), ("СРАВНЕНИЯ", (210, 110, 30), Compare),
                ("СТАТИСТИКА", (30, 150, 170), Stats), ("МАГАЗИН", (200, 140, 20), Shop),
                ("НАСТРОЙКИ", (80, 100, 130), Settings)]
        self.items = []
        for i, (label, col, cls) in enumerate(defs):
            x = 300 + (i % 2) * 680
            if i == len(defs) - 1 and len(defs) % 2 == 1:
                x = 640                                   # последняя кнопка по центру
            y = 370 + (i // 2) * 150
            self.items.append((Button((x, y, 640, 120), label, col, 46), cls))

    def handle(self, e):
        if self.input_lock > 0:
            return
        p = get_click_pos(e)
        if p is not None:
            for b, cls in self.items:
                if b.hit(p):
                    if cls is None:
                        quit_game()
                        return
                    self.app.go(cls(self.app))
                    return

    def update(self, dt):
        self.t += dt
        self.input_lock = max(0.0, self.input_lock - dt)

    def draw(self, surf):
        img, (w, h) = _render_text_cached("FOOTBALL", 150, WHITE, True, True)
        pulse = 1 + 0.03 * math.sin(self.t * 2.5)
        sw, sh = max(1, int(w * pulse)), max(1, int(h * pulse))
        scaled = pygame.transform.scale(img, (sw, sh))
        r = scaled.get_rect(center=(W // 2, sc(140)))
        surf.blit(scaled, r)

        text(surf, "A R E N A", 64, GOLD, (960, 258))
        for sx_design in (360, 1560):
            by = 150 - abs(math.sin(self.t * 3 + sx_design)) * 50
            draw_ball(surf, (sx_design, by), 58, self.t * (2 if sx_design < 960 else -2),
                      BALL_SKINS[self.app.stats["ball_skin"]])
        daily_ready = self.app.daily_remaining() == 0
        for b, cls in self.items:
            b.draw(surf)
            if cls is Shop and daily_ready:                 # красный значок: бонус можно забрать
                cx, cy = b.rect.right / S - 16, b.rect.y / S + 16
                pygame.draw.circle(surf, RED, (sc(cx), sc(cy)), sc(26))
                pygame.draw.circle(surf, WHITE, (sc(cx), sc(cy)), sc(26), 2)
                text(surf, "!", 34, WHITE, (cx, cy), shadow=False)
        text(surf, "Выход — в настройках (или ESC)", 26, (200, 220, 210), (960, 1030), bold=False)


# ---------------------------------------------------------------- пенальти
def draw_keeper(surf, x, y, d, skin=None):
    skin = skin or KEEPER_SKINS["k_default"]
    pygame.draw.ellipse(surf, (5, 20, 15), (x - 25, y + 31, 50, 10))
    pygame.draw.rect(surf, skin["pants"], (x - 13, y + 5, 11, 31), border_radius=4)
    pygame.draw.rect(surf, skin["pants"], (x + 2, y + 5, 11, 31), border_radius=4)
    spread = 0.3 + d
    for sgn in (-1, 1):
        sh = (x + sgn * 16, y - 19)
        hand = (x + sgn * (16 + 38 * spread), y - 19 - 28 * spread)
        pygame.draw.line(surf, skin["sleeve"], sh, hand, 10)
        pygame.draw.circle(surf, (245, 245, 245), hand, 10)
    pygame.draw.rect(surf, skin["jersey"], (x - 18, y - 29, 36, 41), border_radius=10)
    pygame.draw.circle(surf, (240, 200, 160), (x, y - 40), 13)
    pygame.draw.rect(surf, skin["cap"], (x - 13, y - 53, 25, 7), border_radius=4)


class Penalty:
    SHOTS = 5
    _STATIC = None   # (трава, ворота) — готовые поверхности

    @staticmethod
    def _build_static():
        top = sc(700)
        grass = pygame.Surface((W, H - top))
        grass.fill((18, 100, 50))
        for i in range(0, W, sc(200)):
            if (i // sc(200)) % 2 == 0:
                pygame.draw.rect(grass, (22, 115, 58), (i, 0, sc(200), H - top))
        pygame.draw.rect(grass, WHITE, (sc(260), 0, sc(1400), sc(340)), 2)
        pygame.draw.circle(grass, WHITE, (sc(960), sc(935) - top), 4)

        g = pygame.Rect(sc(460), sc(180), sc(1000), sc(480))
        ox, oy = g.x - 7, g.y - 7
        goal = pygame.Surface((g.w + 14, g.h + 7))
        goal.fill(WHITE)                                   # штанги и перекладина
        inner = g.move(-ox, -oy)
        pygame.draw.rect(goal, DARK, inner)
        for x in range(inner.x, inner.right, sc(40)):
            pygame.draw.line(goal, (45, 75, 65), (x, inner.y), (x, inner.bottom), 1)
        for y in range(inner.y, inner.bottom, sc(40)):
            pygame.draw.line(goal, (45, 75, 65), (inner.x, y), (inner.right, y), 1)
        return grass.convert(), goal.convert(), (ox, oy)

    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)
        self.goal = pygame.Rect(sc(460), sc(180), sc(1000), sc(480))
        self.goal_design = pygame.Rect(460, 180, 1000, 480)
        g_d = 20
        cw_d = (self.goal_design.w - 4 * g_d) // 3
        ch_d = (self.goal_design.h - 4 * g_d) // 3
        self.cells_design = [
            pygame.Rect(self.goal_design.x + g_d + c * (cw_d + g_d),
                        self.goal_design.y + g_d + r * (ch_d + g_d), cw_d, ch_d)
            for r in range(3) for c in range(3)
        ]
        self.cells = [pygame.Rect(sc(r.x), sc(r.y), sc(r.w), sc(r.h))
                      for r in self.cells_design]
        self.b_again = Button((420, 700, 340, 100), "ЕЩЁ СЕРИЯ", GREEN, 36)
        self.b_role = Button((790, 700, 340, 100), "СМЕНИТЬ РОЛЬ", BLUE, 36)
        self.b_menu = Button((1160, 700, 340, 100), "В МЕНЮ", RED, 36)
        self.b_shooter = Button((380, 360, 560, 180), "ИГРАТЬ ЗА ИГРОКА", GREEN, 44)
        self.b_keeper = Button((980, 360, 560, 180), "ИГРАТЬ ЗА ВРАТАРЯ", BLUE, 44)
        self.role = None          # None -> экран выбора, "shooter" / "keeper"
        self.reset()
        self.lock = 0.5           # защита от «проскакивания» тапа по кнопке меню

    def reset(self):
        self.shot, self.results = 0, []
        self.choice, self.keeper, self.t = None, None, 0.0
        self.phase = "choose" if self.role else "mode"
        self.lock = 0.35          # чтобы тап по кнопке не засчитался сразу как выбор ячейки

    def set_role(self, role):
        self.role = role
        self.reset()

    @staticmethod
    def ai_shot():
        """Куда бьёт соперник: по углам чаще, в центр реже."""
        return random.choices(range(9), weights=(3, 2, 3, 2, 1, 2, 3, 2, 3))[0]

    def pick(self, i):
        """Игрок выбрал ячейку: куда бить (shooter) или куда прыгнуть (keeper)."""
        if self.role == "keeper":
            self.keeper, self.choice = i, self.ai_shot()
        else:
            self.choice, self.keeper = i, random.randrange(9)
        self.phase, self.t = "anim", 0.0

    def nxt(self):
        self.shot += 1
        self.phase = "final" if self.shot >= self.SHOTS else "choose"
        self.choice = self.keeper = None

    def handle(self, e):
        if self.back.handle(e):
            return
        if self.lock > 0:
            return
        if e.type == pygame.KEYDOWN:
            if self.phase == "mode":
                if e.key == pygame.K_1:
                    self.set_role("shooter")
                elif e.key == pygame.K_2:
                    self.set_role("keeper")
            elif self.phase == "choose" and pygame.K_1 <= e.key <= pygame.K_9:
                self.pick(e.key - pygame.K_1)
            elif self.phase == "result" and e.key in (pygame.K_SPACE, pygame.K_RETURN):
                self.nxt()
        p = get_click_pos(e)
        if p is not None:
            if self.phase == "mode":
                if self.b_shooter.hit(p):
                    self.set_role("shooter")
                elif self.b_keeper.hit(p):
                    self.set_role("keeper")
            elif self.phase == "choose":
                for i, c in enumerate(self.cells):
                    if c.collidepoint(p):
                        self.pick(i)
                        break
            elif self.phase == "result":
                self.nxt()
            elif self.phase == "final":
                if self.b_again.hit(p):
                    self.reset()
                elif self.b_role.hit(p):
                    self.set_role(None)
                elif self.b_menu.hit(p):
                    self.app.go(Menu(self.app))

    def update(self, dt):
        self.lock = max(0.0, self.lock - dt)
        if self.phase == "anim":
            self.t += dt / 0.8
            if self.t >= 1:
                self.phase = "result"
                goal = self.choice != self.keeper
                if self.role == "keeper":
                    ok = not goal                      # успех вратаря — отбитый удар
                    if ok:
                        self.app.stats["penalties_saved"] += 1
                        self.app.add_coins(3)              # отбить сложнее -> 3 монеты
                        self.app.save()
                else:
                    ok = goal                          # успех игрока — забитый гол
                    if ok:
                        self.app.stats["penalties_scored"] += 1
                        self.app.add_coins(1)
                        self.app.save()
                self.results.append(ok)
                if len(self.results) == self.SHOTS and all(self.results):
                    self.app.unlock("saves5" if self.role == "keeper" else "goals5")

    def draw(self, surf):
        if Penalty._STATIC is None:
            Penalty._STATIC = Penalty._build_static()
        grass, goal_img, goal_pos = Penalty._STATIC
        surf.blit(grass, (0, sc(700)))
        pygame.draw.line(surf, WHITE, (0, sc(700)), (W, sc(700)), 3)
        surf.blit(goal_img, goal_pos)
        g = self.goal

        base = (g.centerx, g.bottom - sc(130))
        kx, ky, d = base[0], base[1], 0.0
        if self.keeper is not None:
            k = ease(self.t * 1.5) if self.phase == "anim" else 1.0
            tx, ty = self.cells[self.keeper].center
            kx = base[0] + (tx - base[0]) * k
            ky = base[1] + (ty - base[1]) * k
            d = k * min(1.0, abs(tx - base[0]) / sc(400))
        draw_keeper(surf, kx, ky, d, KEEPER_SKINS[self.app.stats["keeper_skin"]])

        keeper_role = self.role == "keeper"
        mp = pygame.mouse.get_pos()
        for i, c in enumerate(self.cells):
            if self.phase == "mode":
                break
            border = None
            if self.phase == "choose":
                hov = c.collidepoint(mp)
                col = (255, 255, 255, 120 if hov else 45)
                border = (255, 255, 255, 200 if hov else 90)
            elif self.phase == "anim":
                sel = self.keeper if keeper_role else self.choice
                col = (255, 255, 255, 110 if i == sel else 25)
            elif keeper_role:
                # синий — куда прыгнул вратарь, красный — куда летел мяч, зелёный — отбил
                if i == self.keeper and i == self.choice:
                    col = (35, 190, 85, 205)
                elif i == self.keeper:
                    col = (50, 120, 225, 205)
                elif i == self.choice:
                    col = (215, 45, 50, 205)
                else:
                    col = (255, 255, 255, 25)
            else:
                col = (215, 45, 50, 205) if i == self.keeper else (35, 190, 85, 175)
            dc = self.cells_design[i]
            if self.phase in ("result", "final") and i == self.choice:
                panel(surf, dc, col, 9, (255, 255, 255, 255), 4)
            else:
                panel(surf, dc, col, 9, border, 2)
            text(surf, str(i + 1), 56, WHITE,
                 (dc.x + dc.w / 2, dc.y + dc.h / 2))

        start = (sc(960), sc(935))
        end = (self.cells[self.choice].centerx, self.cells[self.choice].centery) if self.choice is not None else start
        p = ease(self.t) if self.phase == "anim" else (1.0 if self.choice is not None else 0.0)
        bx = start[0] + (end[0] - start[0]) * p
        by = start[1] + (end[1] - start[1]) * p - math.sin(math.pi * p) * sc(70)
        draw_ball(surf, (bx / S, by / S), 36 - 14 * p, p * 14, BALL_SKINS[self.app.stats["ball_skin"]])

        title = "СЕРИЯ ПЕНАЛЬТИ — ВРАТАРЬ" if keeper_role else "СЕРИЯ ПЕНАЛЬТИ"
        text(surf, title, 54, WHITE, (960, 60))
        for i in range(self.SHOTS):
            c = GRAY
            if i < len(self.results):
                c = (40, 200, 90) if self.results[i] else (225, 55, 60)
            cx = sc(960) + (i - 2) * sc(70)
            pygame.draw.circle(surf, c, (cx, sc(125)), 12)
            pygame.draw.circle(surf, WHITE, (cx, sc(125)), 12, 2)

        if self.phase == "mode":
            panel(surf, (340, 230, 1240, 400), (0, 0, 0, 190), 24, (255, 255, 255, 140), 2)
            text(surf, "Выбери, за кого играть", 50, WHITE, (960, 295))
            self.b_shooter.draw(surf)
            self.b_keeper.draw(surf)
            text(surf, "Бьёшь пенальти по воротам", 28, (220, 235, 228), (660, 580),
                 bold=False, shadow=False)
            text(surf, "Отбиваешь удары соперника", 28, (220, 235, 228), (1260, 580),
                 bold=False, shadow=False)
            text(surf, "Нажми кнопку или клавишу 1 / 2", 34, WHITE, (960, 760))
        elif self.phase == "choose":
            if keeper_role:
                text(surf, "Выбери, куда прыгнет вратарь (кнопка или клавиши 1–9)", 38, WHITE, (960, 760))
            else:
                text(surf, "Выбери, куда бить (кнопка или клавиши 1–9)", 38, WHITE, (960, 760))
        elif self.phase == "result":
            saved = self.choice == self.keeper
            if keeper_role:
                if saved:
                    text(surf, "ОТБИЛ! Круто!", 96, (60, 230, 110), (960, 770))
                else:
                    text(surf, "Гол... Не угадал!", 84, (240, 70, 70), (960, 770))
            elif not saved:
                text(surf, "ГОЛ! Круто!", 96, (60, 230, 110), (960, 770))
            else:
                text(surf, "Вратарь спас... Плохо!", 84, (240, 70, 70), (960, 770))
            text(surf, "Клик или пробел — дальше", 30, WHITE, (960, 1030), bold=False)
        elif self.phase == "final":
            good = sum(self.results)
            panel(surf, (400, 280, 1120, 560), (0, 0, 0, 200), 18, (255, 255, 255, 120), 2)
            text(surf, "Серия окончена", 64, WHITE, (960, 360))
            if keeper_role:
                text(surf, f"Отбито: {good} из {self.SHOTS}", 90, GOLD, (960, 470))
                msg = ("Железная стена! Ты настоящий вратарь!" if good == 5 else
                       "Отличная игра в воротах!" if good >= 3 else "Тренируйся — получится!")
            else:
                text(surf, f"Забито: {good} из {self.SHOTS}", 90, GOLD, (960, 470))
                msg = ("Идеально! Ты настоящий снайпер!" if good == 5 else
                       "Отличный результат!" if good >= 3 else "Тренируйся — получится!")
            text(surf, msg, 44, WHITE, (960, 580))
            self.b_again.rect.topleft = (sc(420), sc(660))
            self.b_role.rect.topleft = (sc(790), sc(660))
            self.b_menu.rect.topleft = (sc(1160), sc(660))
            self.b_again.draw(surf)
            self.b_role.draw(surf)
            self.b_menu.draw(surf)

        self.back.draw(surf)


# ---------------------------------------------------------------- матчи
# Встроенные (запасные) лиги — используются, только если нет файла data/teams.txt
_DEFAULT_LEAGUES = [
    ("АПЛ", [("Манчестер Сити", 93), ("Арсенал", 90), ("Ливерпуль", 89), ("Челси", 84),
             ("Манчестер Юнайтед", 82), ("Тоттенхэм", 82)]),
    ("ЛАЛИГА", [("Реал Мадрид", 92), ("Барселона", 90), ("Атлетико Мадрид", 86)]),
    ("СЕРИЯ А", [("Интер", 89), ("Ювентус", 84), ("Милан", 83), ("Наполи", 83), ("Рома", 80)]),
    ("БУНДЕСЛИГА", [("Бавария", 91), ("Байер Леверкузен", 86), ("Боруссия Дортмунд", 83)]),
    ("ЛИГА 1", [("ПСЖ", 90)]),
    ("ОСТАЛЬНОЙ МИР", [("Бенфика", 80), ("Порту", 79), ("Аякс", 78), ("Галатасарай", 76),
                      ("Зенит", 76), ("Селтик", 74)]),
]
LEAGUES = load_leagues(_DEFAULT_LEAGUES)                 # лиги и команды берутся из data/teams.txt
TEAMS = [t for _, teams in LEAGUES for t in teams]       # общий список всех команд


class Match:
    RH = 68
    _ROWS = {}      # кэш отрисованных строк списка (ключ -> Surface)

    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)
        self.lock = 0.5                      # тап по кнопке меню не должен сразу выбрать лигу
        self.view = [None, None]             # None — список лиг; число — открыта лига с таким номером
        self.chosen = [None, None]           # выбранные команды: (номер лиги, номер команды)
        self.scroll = [0.0, 0.0]
        self.panels_design = [pygame.Rect(80, 270, 680, 680), pygame.Rect(1160, 270, 680, 680)]
        self.panels = [pygame.Rect(sc(r.x), sc(r.y), sc(r.w), sc(r.h)) for r in self.panels_design]
        self.scroll_up = [pygame.Rect(sc(768), sc(540), sc(60), sc(65)),
                          pygame.Rect(sc(1848), sc(540), sc(60), sc(65))]
        self.scroll_down = [pygame.Rect(sc(768), sc(615), sc(60), sc(65)),
                            pygame.Rect(sc(1848), sc(615), sc(60), sc(65))]
        self.b_close = [Button((r.right - 235, 226, 235, 42), "ЗАКРЫТЬ", RED, 24)
                        for r in self.panels_design]
        self.state = "idle"
        self.minute = 0.0
        self.events = []
        self.btn = Button((790, 290, 340, 90), "СИМУЛИРОВАТЬ", BLUE, 32)
        self.row_w = self.panels[0].w - sc(24)
        self.row_h = sc(self.RH - 10)

    # ---- данные списков
    def count(self, pi):
        v = self.view[pi]
        return len(LEAGUES) if v is None else len(LEAGUES[v][1])

    def max_scroll(self, pi):
        return max(0, sc(self.count(pi) * self.RH) - self.panels[pi].h)

    def team(self, pi):
        c = self.chosen[pi]
        return LEAGUES[c[0]][1][c[1]] if c else None

    def ready(self):
        return self.chosen[0] is not None and self.chosen[1] is not None

    def row_key(self, pi, i):
        v = self.view[pi]
        if v is None:
            name, teams = LEAGUES[i]
            return ("L", name, len(teams))
        name, rating = LEAGUES[v][1][i]
        ref = (v, i)
        variant = "selected" if ref == self.chosen[pi] else ("disabled" if ref == self.chosen[1 - pi] else "normal")
        return ("T", name, rating, variant)

    def _row(self, key):
        s = Match._ROWS.get(key)
        if s is None:
            s = Match._ROWS[key] = self._build_row(key)
        return s

    def _build_row(self, key):
        s = pygame.Surface((self.row_w, self.row_h), pygame.SRCALPHA)
        variant = key[3] if key[0] == "T" else "normal"
        if variant == "selected":
            pygame.draw.rect(s, (30, 170, 95, 230), s.get_rect(), border_radius=8)
            pygame.draw.rect(s, (255, 255, 255, 220), s.get_rect(), 2, border_radius=8)
        else:
            pygame.draw.rect(s, (255, 255, 255, 14 if variant == "normal" else 5), s.get_rect(), border_radius=8)
        cy = (self.RH - 10) / 2
        left = (12 / S, cy)
        if key[0] == "L":
            _, name, n = key
            text(s, short(name, 22), 36, WHITE, left, "midleft", shadow=False)
            text(s, f"{n} {ru_plural(n, 'команда', 'команды', 'команд')}", 26, GOLD,
                 (self.row_w / S - 56 / S, cy), "midright", shadow=False)
            xr, c = self.row_w - 22, self.row_h / 2          # стрелка «открыть»
            pygame.draw.lines(s, (200, 220, 210), False,
                              [(xr - 6, c - 10), (xr + 5, c), (xr - 6, c + 10)], 3)
        else:
            _, name, rating, _ = key
            dim = variant == "disabled"
            text(s, name, 32, (125, 135, 130) if dim else WHITE, left, "midleft", shadow=False)
            text(s, str(rating), 30, (110, 100, 60) if dim else GOLD,
                 (self.row_w / S - 12 / S, cy), "midright", shadow=False)
        return s.convert_alpha()

    # ---- действия
    def click_row(self, pi, idx):
        if self.view[pi] is None:                           # выбрали лигу — показываем её команды
            self.view[pi], self.scroll[pi] = idx, 0.0
            self.lock = 0.3                                 # повторное событие тапа не должно выбрать команду
            return
        ref = (self.view[pi], idx)
        if self.state == "run" or ref == self.chosen[1 - pi]:
            return
        self.chosen[pi] = ref
        self.state = "idle"

    def simulate(self):
        ra, rb = self.team(0)[1], self.team(1)[1]
        la = max(0.35, 1.35 * (1 + (ra - rb) / 45))
        lb = max(0.35, 1.35 * (1 + (rb - ra) / 45))
        ga, gb = min(6, poisson(la)), min(6, poisson(lb))
        ev = [(random.randint(1, 90), 0) for _ in range(ga)] + [(random.randint(1, 90), 1) for _ in range(gb)]
        self.events = sorted(ev)
        self.minute, self.state = 0.0, "run"
        self.app.stats["matches"] += 1
        self.app.add_coins(3)
        self.app.save()

    def handle(self, e):
        if self.back.handle(e):
            return
        if self.lock > 0:
            return
        if e.type == pygame.MOUSEWHEEL:
            mp = pygame.mouse.get_pos()
            for pi, pr in enumerate(self.panels):
                if pr.collidepoint(mp):
                    self.scroll[pi] = max(0, min(self.max_scroll(pi), self.scroll[pi] - e.y * sc(60)))
            return
        p = get_click_pos(e)
        if p is None:
            return
        if self.btn.hit(p) and self.ready() and self.state != "run":
            self.simulate()
            return
        for i in range(2):
            if self.view[i] is not None and self.b_close[i].hit(p):     # «передумал» — назад к списку лиг
                self.view[i], self.scroll[i] = None, 0.0
                self.lock = 0.3
                return
            if self.scroll_up[i].collidepoint(p):
                self.scroll[i] = max(0, self.scroll[i] - sc(self.RH * 3))
                return
            if self.scroll_down[i].collidepoint(p):
                self.scroll[i] = min(self.max_scroll(i), self.scroll[i] + sc(self.RH * 3))
                return
        for pi, pr in enumerate(self.panels):
            if pr.collidepoint(p):
                idx = int((p[1] - pr.y + self.scroll[pi]) // sc(self.RH))
                if 0 <= idx < self.count(pi):
                    self.click_row(pi, idx)

    def update(self, dt):
        self.lock = max(0.0, self.lock - dt)
        if self.state == "run":
            self.minute += dt * 18
            if self.minute >= 90:
                self.minute, self.state = 90, "done"

    def _draw_arrow(self, surf, rect, direction):
        hov = rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(surf, (30, 40, 50), rect, border_radius=6)
        pygame.draw.rect(surf, WHITE, rect, 2, border_radius=6)
        col = (255, 255, 255) if hov else (200, 220, 210)
        if direction == "up":
            pts = [(rect.centerx, rect.top + 7), (rect.left + 7, rect.bottom - 7),
                   (rect.right - 7, rect.bottom - 7)]
        else:
            pts = [(rect.centerx, rect.bottom - 7), (rect.left + 7, rect.top + 7),
                   (rect.right - 7, rect.top + 7)]
        pygame.draw.polygon(surf, col, pts)

    def draw(self, surf):
        mp = pygame.mouse.get_pos()
        text(surf, "СИМУЛЯЦИЯ МАТЧЕЙ", 52, WHITE, (960, 55))
        panel(surf, (340, 105, 1240, 120), (0, 0, 0, 170), 15, (255, 255, 255, 110), 2)
        shown = [ev for ev in self.events if ev[0] <= int(self.minute)]
        sa = sum(1 for _, s in shown if s == 0)
        sb = sum(1 for _, s in shown if s == 1)
        t0, t1 = self.team(0), self.team(1)
        for t, pos, anc in ((t0, (800, 165), "midright"), (t1, (1120, 165), "midleft")):
            if t:
                text(surf, t[0], 36, WHITE, pos, anc)
            else:
                text(surf, "Выбери команду", 30, (150, 165, 158), pos, anc)
        if self.state == "idle":
            text(surf, "VS", 70, GOLD, (960, 165))
        else:
            text(surf, f"{sa} : {sb}", 80, GOLD, (960, 165))

        for pi, pr in enumerate(self.panels):
            prd = self.panels_design[pi]
            v = self.view[pi]
            title = (f"КОМАНДА {pi + 1} — ВЫБЕРИ ЛИГУ" if v is None
                     else f"КОМАНДА {pi + 1} · {short(LEAGUES[v][0], 16)}")
            text(surf, title, 28, (200, 230, 210), (prd.x + 12, 250), "midleft")
            if v is not None:
                self.b_close[pi].draw(surf)
            panel(surf, prd, (0, 0, 0, 110), 13, (255, 255, 255, 70), 2)
            surf.set_clip(pr.inflate(-sc(6), -sc(6)))
            n, rh = self.count(pi), sc(self.RH)
            first = max(0, int(self.scroll[pi] // rh))
            last = min(n - 1, int((self.scroll[pi] + pr.h) // rh))
            for i in range(first, last + 1):
                y = pr.y + sc(i * self.RH) - self.scroll[pi]
                key = self.row_key(pi, i)
                surf.blit(self._row(key), (pr.x + sc(12), y + sc(5)))
                if key[0] == "L" or key[3] == "normal":
                    r = pygame.Rect(pr.x + sc(12), y + sc(5), self.row_w, self.row_h)
                    if r.collidepoint(mp):
                        pygame.draw.rect(surf, (255, 255, 255, 60), r, 2, border_radius=8)
            surf.set_clip(None)
            mx = self.max_scroll(pi)
            if mx > 0:                                       # прокрутка нужна только для длинных списков
                bar_h = sc(120)
                by = pr.y + sc(10) + (pr.h - sc(20) - bar_h) * (self.scroll[pi] / mx)
                pygame.draw.rect(surf, WHITE, (pr.right - 5, by, 3, bar_h), border_radius=2)
                self._draw_arrow(surf, self.scroll_up[pi], "up")
                self._draw_arrow(surf, self.scroll_down[pi], "down")

        ready = self.ready()
        self.btn.enabled = ready and self.state != "run"
        self.btn.label = ("ВЫБЕРИ КОМАНДЫ" if self.state == "idle" and not ready else
                          {"idle": "СИМУЛИРОВАТЬ", "run": "ИДЁТ МАТЧ...", "done": "ЕЩЁ РАЗ"}[self.state])
        self.btn.draw(surf)
        if self.state != "idle" and ready:
            text(surf, f"{int(self.minute)}'" if self.state == "run" else "Матч окончен",
                 34, WHITE, (960, 415))
            for i, (m, s) in enumerate(shown):
                name = (t0 if s == 0 else t1)[0]
                text(surf, f"{m}'  {name}", 24, WHITE, (960, 470 + i * 36))
        if self.state == "done" and ready:
            res = "Ничья" if sa == sb else f"Победил {(t0 if sa > sb else t1)[0]}"
            text(surf, res, 36, GOLD, (960, 930))
        text(surf, "Нажми на лигу, потом на команду  ·  «ЗАКРЫТЬ» — вернуться к списку лиг", 24,
             (200, 220, 210), (960, 1030), bold=False, shadow=False)
        self.back.draw(surf)


# ---------------------------------------------------------------- викторина
_DEFAULT_QUIZ = [
    ("Из какой страны Криштиану Роналду?", ["Португалия", "Бразилия", "Испания"], 0),
    ("Сколько игроков одной команды одновременно на поле?", ["9", "11", "10"], 1),
    ("Какая карточка означает удаление с поля?", ["Жёлтая", "Красная", "Синяя"], 1),
    ("В какой стране проходил чемпионат мира 2022 года?", ["Россия", "Бразилия", "Катар"], 2),
    ("Из какой страны Лионель Месси?", ["Аргентина", "Уругвай", "Испания"], 0),
    ("В каком году был основан Реал Мадрид?", ["1899", "1902", "1910"], 1),
    ("Кто стал чемпионом мира 2018 года?", ["Хорватия", "Франция", "Бельгия"], 1),
    ("Сколько Золотых мячей выиграл Лионель Месси?", ["7", "8", "9"], 1),
    ("Какая сборная выиграла самый первый чемпионат мира (1930)?", ["Аргентина", "Бразилия", "Уругвай"], 2),
    ("В каком году была основана ФИФА?", ["1886", "1904", "1930"], 1),
]
QUIZ = load_quiz(_DEFAULT_QUIZ)             # вопросы берутся из data/quiz.txt


class Quiz:
    def __init__(self, app, level=None):
        if level is None:                                  # продолжаем с места, где остановились
            level = app.stats["quiz_progress"]
        self.app, self.level = app, level
        self.lock = 0.5          # после входа ввод блокируется на 0.5 с (тап по кнопке меню не должен выбрать ответ)
        self.back = BackButton(app)
        self.b1 = Button((460, 880, 480, 100), "ДАЛЬШЕ", GREEN, 36)
        self.b2 = Button((980, 880, 480, 100), "В МЕНЮ", RED, 36)
        self.answers_design = [pygame.Rect(460, 440 + i * 130, 1000, 105) for i in range(3)]
        self.answers = [pygame.Rect(sc(r.x), sc(r.y), sc(r.w), sc(r.h)) for r in self.answers_design]
        self.load()

    def load(self):
        q, opts, ans = QUIZ[self.level]
        correct = opts[ans]
        o = opts[:]
        random.shuffle(o)
        self.q, self.opts, self.correct = q, o, o.index(correct)
        self.picked, self.win = None, False

    def handle(self, e):
        if self.lock > 0:
            return
        if self.back.handle(e):
            return
        p = get_click_pos(e)
        if p is None:
            return
        if self.picked is None:
            for i, r in enumerate(self.answers):
                if r.collidepoint(p):
                    self.picked = i
                    if i == self.correct:
                        st = self.app.stats
                        st["quiz_levels"] = max(st["quiz_levels"], self.level + 1)
                        self.app.add_coins(2)
                        self.win = self.level == len(QUIZ) - 1
                        if self.win:
                            if st["quiz_clean"]:
                                self.app.unlock("quiz_clean")
                            st["quiz_progress"], st["quiz_clean"] = 0, True   # новый заход начнётся с 1-го вопроса
                        else:
                            st["quiz_progress"] = self.level + 1              # этот вопрос пройден
                        self.app.save()
                        self.b1.label = "ЗАНОВО" if self.win else "ДАЛЬШЕ"
                    else:
                        self.app.stats["quiz_clean"] = False          # ошибка в этом заходе
                        self.app.save()
                        self.b1.label = "ПОПРОБОВАТЬ СНОВА"
                    return
        else:
            if self.b1.hit(p):
                if self.picked == self.correct and not self.win:
                    self.level += 1
                elif self.win:
                    self.level = 0
                self.load()
            elif self.b2.hit(p):
                self.app.go(Menu(self.app))

    def update(self, dt):
        self.lock = max(0.0, self.lock - dt)

    def draw(self, surf):
        text(surf, "ФУТБОЛЬНАЯ ВИКТОРИНА", 52, WHITE, (960, 55))
        n = len(QUIZ)
        done = self.level + (1 if self.picked == self.correct else 0)
        if n <= 30:                                        # отдельные полоски — по одной на вопрос
            gap = 12 if n <= 12 else 6
            bw = (1108 - gap * (n - 1)) / n
            for i in range(n):
                if i < self.level or (i == self.level and self.picked == self.correct):
                    col = (40, 200, 90)
                elif i == self.level:
                    col = GOLD
                else:
                    col = (70, 85, 80)
                panel(surf, (406 + i * (bw + gap), 110, bw, 18), col + (255,), 4)
        else:                                              # вопросов много — одна сплошная полоса
            panel(surf, (406, 110, 1108, 18), (70, 85, 80, 255), 4)
            if done:
                panel(surf, (406, 110, max(8, 1108 * done / n), 18), (40, 200, 90, 255), 4)
        text(surf, f"Уровень {self.level + 1} из {len(QUIZ)}", 36, GOLD, (960, 170))
        panel(surf, (360, 210, 1200, 200), (0, 0, 0, 175), 15, (255, 255, 255, 110), 2)
        lines = wrap(self.q, 46, 1100)
        y0 = 310 - (len(lines) - 1) * 28
        for i, ln in enumerate(lines):
            text(surf, ln, 46, WHITE, (960, y0 + i * 56))

        mp = pygame.mouse.get_pos()
        for i, r in enumerate(self.answers):
            rd = self.answers_design[i]
            hov = r.collidepoint(mp) and self.picked is None
            if self.picked is None:
                col = (60, 110, 200) if hov else (40, 80, 170)
            elif i == self.correct:
                col = (35, 175, 85)
            elif i == self.picked:
                col = (215, 50, 55)
            else:
                col = (50, 60, 70)
            rr = r.inflate(sc(14), sc(8)) if hov else r
            pygame.draw.rect(surf, (10, 15, 20), rr.move(0, 3), border_radius=13)
            pygame.draw.rect(surf, col, rr, border_radius=13)
            pygame.draw.rect(surf, WHITE, rr, 2, border_radius=13)
            text(surf, "ABC"[i], 44, GOLD, (rd.x + 55, rd.y + rd.h / 2))
            text(surf, self.opts[i], 44, WHITE, (rd.x + 120, rd.y + rd.h / 2), "midleft")

        if self.picked is not None:
            if self.win:
                text(surf, f"ПОБЕДА! Все {len(QUIZ)} уровней пройдены!", 52, GOLD, (960, 840))
            elif self.picked == self.correct:
                text(surf, "Верно!", 52, (60, 230, 110), (960, 840))
            else:
                text(surf, "Неверно, попробуй ещё раз", 52, (240, 80, 80), (960, 840))
            self.b1.draw(surf)
            self.b2.draw(surf)
        self.back.draw(surf)


# ---------------------------------------------------------------- сравнения
_DEFAULT_PAIRS = [
    ("Игроки", "Криштиану Роналду", "Лионель Месси"),
    ("Клубы", "Реал Мадрид", "Барселона"),
    ("Клубы", "Бавария", "Боруссия Дортмунд"),
    ("Клубы", "Манчестер Юнайтед", "Ливерпуль"),
    ("Клубы", "Арсенал", "Тоттенхэм"),
    ("Клубы", "Милан", "Интер"),
    ("Легенды", "Пеле", "Диего Марадона"),
    ("Игроки", "Неймар", "Килиан Мбаппе"),
    ("Игроки", "Эрлинг Холанд", "Килиан Мбаппе"),
    ("Легенды", "Зинедин Зидан", "Роналдиньо"),
    ("Тренеры", "Пеп Гвардиола", "Жозе Моуринью"),
    ("Тренеры", "Алекс Фергюсон", "Арсен Венгер"),
    ("Сборные", "Бразилия", "Аргентина"),
    ("Сборные", "Германия", "Италия"),
    ("Трофеи", "Лига чемпионов", "Чемпионат мира"),
    ("Вратари", "Мануэль Нойер", "Джанлуиджи Буффон"),
    ("Лиги", "Английская премьер-лига", "Ла Лига"),
    ("Стиль", "Красивая атака", "Железная защита"),
]
PAIRS = load_pairs(_DEFAULT_PAIRS)          # пары берутся из data/comparisons.txt


class Compare:
    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)
        self.order = []
        self.pick = None
        self.t = 0.0
        self.entry_lock = 0.5
        self.next_pair()
        self.left = pygame.Rect(sc(130), sc(250), sc(760), sc(600))
        self.right = pygame.Rect(sc(1030), sc(250), sc(760), sc(600))

    def next_pair(self):
        if not self.order:
            self.order = list(range(len(PAIRS)))
            random.shuffle(self.order)
        self.cur = PAIRS[self.order.pop()]
        self.pick, self.t = None, 0.0

    def choose(self, side):
        if self.pick is None:
            self.pick, self.t = side, 0.0
            self.app.stats["comparisons"] += 1
            self.app.add_coins(1)
            self.app.save()

    def handle(self, e):
        # После перехода в сравнения блокируем выбор на 0.5 секунды:
        # это также отсекает повторное событие от тапа по кнопке меню.
        if self.entry_lock > 0:
            return
        if self.back.handle(e):
            return
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_LEFT, pygame.K_1):
                self.choose(0)
            elif e.key in (pygame.K_RIGHT, pygame.K_2):
                self.choose(1)
        p = get_click_pos(e)
        if p is not None:
            if self.left.collidepoint(p):
                self.choose(0)
            elif self.right.collidepoint(p):
                self.choose(1)

    def update(self, dt):
        if self.entry_lock > 0:
            self.entry_lock = max(0.0, self.entry_lock - dt)
        if self.pick is not None:
            self.t += dt
            if self.t > 0.9:
                self.next_pair()

    def draw(self, surf):
        text(surf, "ФУТБОЛЬНЫЕ СРАВНЕНИЯ", 52, WHITE, (960, 55))
        text(surf, f"{self.cur[0].upper()} — выбери одного", 40, GOLD, (960, 140))
        mp = pygame.mouse.get_pos()
        for side, (r, name, col) in enumerate([
                (self.left, self.cur[1], (35, 100, 200)),
                (self.right, self.cur[2], (200, 55, 60))]):
            hov = r.collidepoint(mp) and self.pick is None
            rr = r.inflate(sc(30), sc(30)) if hov else r
            c = col
            if self.pick is not None:
                if self.pick == side:
                    c = (35, 180, 90)
                    rr = r.inflate(sc(24), sc(24))
                else:
                    c = (60, 65, 75)
            pygame.draw.rect(surf, (10, 15, 20), rr.move(0, 5), border_radius=20)
            pygame.draw.rect(surf, c, rr, border_radius=20)
            pygame.draw.rect(surf, WHITE, rr, 2, border_radius=20)
            lines = wrap(name, 74, rr.w / S - 80)
            y0 = (rr.centery / S) - (len(lines) - 1) * 46
            for i, ln in enumerate(lines):
                text(surf, ln, 74, WHITE, (rr.centerx / S, y0 + i * 92))
            if self.pick == side:
                text(surf, "ТВОЙ ВЫБОР", 36, GOLD, (rr.centerx / S, (rr.bottom - sc(55)) / S))
        pygame.draw.circle(surf, (0, 0, 0), (sc(960), sc(550)), 35)
        pygame.draw.circle(surf, GOLD, (sc(960), sc(550)), 35, 3)
        text(surf, "VS", 60, WHITE, (960, 550), shadow=False)
        text(surf, f"Выбрано сравнений: {self.app.stats['comparisons']}", 34, WHITE, (960, 930))
        text(surf, "Клик / ← →", 24, (200, 220, 210), (960, 1030), bold=False, shadow=False)
        self.back.draw(surf)


# ---------------------------------------------------------------- магазин
class Shop:
    COLS_X = (330, 750, 1170)
    ROWS = (("keeper", "СКИНЫ ВРАТАРЯ", KEEPER_SKINS, 300),
            ("ball", "СКИНЫ МЯЧА", BALL_SKINS, 665))

    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)
        self.lock = 0.35                 # защита от «проскакивания» тапа по кнопке меню
        self.msg, self.msg_t, self.msg_col = "", 0.0, WHITE
        self.b_daily = Button((1250, 135, 300, 85), "ЗАБРАТЬ", GREEN, 36)
        self.cards = []
        for kind, _, skins, y in self.ROWS:
            for i, (sid, sk) in enumerate(skins.items()):
                x = self.COLS_X[i]
                self.cards.append((kind, sid, sk, x, y, Button((x + 40, y + 215, 300, 65), "КУПИТЬ", BLUE, 32)))

    def say(self, s, col):
        self.msg, self.msg_t, self.msg_col = s, 1.6, col

    def act(self, kind, sid, skin):
        st = self.app.stats
        if sid not in st["owned"]:
            if st["coins"] < skin["price"]:
                self.say("Не хватает монет!", (240, 80, 80))
                return
            st["coins"] -= skin["price"]
            st["owned"].append(sid)
            self.say("Куплено и надето!", (60, 230, 110))
        st[kind + "_skin"] = sid
        self.app.save()

    def handle(self, e):
        if self.back.handle(e):
            return
        if self.lock > 0:
            return
        p = get_click_pos(e)
        if p is None:
            return
        if self.b_daily.rect.collidepoint(p):
            self.lock = 0.35
            if self.app.claim_daily():
                self.say("Бонус получен! Возвращайся завтра", (60, 230, 110))
            else:
                self.say("Бонус ещё не готов — смотри таймер", (240, 80, 80))
            return
        for kind, sid, sk, x, y, b in self.cards:
            if b.rect.collidepoint(p):
                self.lock = 0.35
                self.act(kind, sid, sk)
                return

    def update(self, dt):
        self.lock = max(0.0, self.lock - dt)
        self.msg_t = max(0.0, self.msg_t - dt)

    def draw(self, surf):
        st = self.app.stats
        text(surf, "МАГАЗИН", 64, WHITE, (960, 60))
        draw_coin(surf, (1620, 60), 30)
        text(surf, str(st["coins"]), 56, GOLD, (1665, 60), "midleft")

        # ежедневный бонус
        rem = int(self.app.daily_remaining() + 0.999)
        ready = self.app.daily_remaining() == 0
        panel(surf, (330, 115, 1260, 125), (0, 0, 0, 170), 22, (255, 255, 255, 120), 2)
        draw_coin(surf, (395, 178), 38)
        text(surf, "ЕЖЕДНЕВНЫЙ БОНУС", 40, WHITE, (460, 155), "midleft")
        if ready:
            text(surf, f"+{self.app.DAILY_COINS} монет — можно забрать!", 32, GOLD, (460, 203), "midleft")
        else:
            t = f"{rem // 3600:02d}:{(rem % 3600) // 60:02d}:{rem % 60:02d}"
            text(surf, f"Следующий бонус через {t}", 32, (220, 235, 228), (460, 203), "midleft")
        self.b_daily.enabled = ready
        self.b_daily.draw(surf)

        # скины
        for kind, label, skins, y in self.ROWS:
            text(surf, label, 36, GOLD, (330, y - 30), "midleft")
        spin = pygame.time.get_ticks() / 1000
        for kind, sid, sk, x, y, b in self.cards:
            owned = sid in st["owned"]
            eq = st[kind + "_skin"] == sid
            border = (60, 230, 110, 255) if eq else (255, 255, 255, 130)
            panel(surf, (x, y, 380, 300), (0, 0, 0, 150), 20, border, 5 if eq else 2)
            cx = x + 190
            if kind == "keeper":
                draw_keeper(surf, sc(cx), sc(y + 112), 0.0, sk)
            else:
                draw_ball(surf, (cx, y + 105), 55, spin, sk)
            text(surf, sk["name"], 34, WHITE, (cx, y + 185))
            if eq:
                b.label, b.color = "ВЫБРАНО", GREEN
            elif owned:
                b.label, b.color = "НАДЕТЬ", BLUE
            else:
                b.label = f"КУПИТЬ — {sk['price']}"
                b.color = (200, 140, 20) if st["coins"] >= sk["price"] else (120, 105, 70)
            b.draw(surf)

        if self.msg_t > 0:
            text(surf, self.msg, 44, self.msg_col, (960, 1030))
        else:
            text(surf, "Покупка сразу надевает скин", 26, (200, 220, 210), (960, 1030), bold=False)
        self.back.draw(surf)


# ---------------------------------------------------------------- настройки
class Settings:
    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)
        self.lock = 0.4                  # «ВЫХОД» необратим: не даём проскочить случайному тапу
        self.b_music = Button((640, 290, 640, 130), "", GREEN, 46)
        self.b_ach = Button((640, 440, 640, 130), "ДОСТИЖЕНИЯ", (200, 140, 20), 46)
        self.b_exit = Button((640, 590, 640, 130), "ВЫХОД", RED, 46)
        self.has_music = find_music() is not None

    def handle(self, e):
        if self.back.handle(e):
            return
        if self.lock > 0:
            return
        p = get_click_pos(e)
        if p is not None:
            if self.b_music.hit(p):
                st = self.app.stats
                self.lock = 0.35        # один тап может прийти как два события -> иначе переключит дважды
                st["music_on"] = not st["music_on"]
                music_set(st["music_on"])
                self.app.save()
            elif self.b_ach.hit(p):
                self.app.go(Achievements(self.app))
            elif self.b_exit.hit(p):
                quit_game()

    def update(self, dt):
        self.lock = max(0.0, self.lock - dt)

    def draw(self, surf):
        text(surf, "НАСТРОЙКИ", 64, WHITE, (960, 80))
        on = self.app.stats["music_on"]
        self.b_music.label = "МУЗЫКА: ВКЛ" if on else "МУЗЫКА: ВЫКЛ"
        self.b_music.color = GREEN if on else GRAY
        self.b_music.draw(surf)
        self.b_ach.draw(surf)
        self.b_exit.draw(surf)
        n = len(set(self.app.stats["achievements"]) & set(ACHIEVEMENTS))
        text(surf, f"Достижений получено: {n} из {len(ACHIEVEMENTS)}", 32, (220, 235, 228), (960, 790),
             bold=False)
        def _src(name):
            return "файл" if DATA_SOURCES.get(name) else "встроенные"
        text(surf, f"Вопросы: {len(QUIZ)} ({_src('quiz.txt')})  ·  Сравнения: {len(PAIRS)} ({_src('comparisons.txt')})"
                   f"  ·  Команды: {len(TEAMS)} в {len(LEAGUES)} {ru_plural(len(LEAGUES), 'лиге', 'лигах', 'лигах')}"
                   f" ({_src('teams.txt')})", 24, (200, 220, 210), (960, 960),
             bold=False, shadow=False)
        folder = DATA_DIR if len(DATA_DIR) <= 70 else "…" + DATA_DIR[-69:]
        text(surf, f"Папка данных: {folder}", 22, (150, 175, 165), (960, 1000), bold=False, shadow=False)
        if DATA_WARNINGS:
            more = f"  (и ещё {len(DATA_WARNINGS) - 1})" if len(DATA_WARNINGS) > 1 else ""
            text(surf, f"Данные: {DATA_WARNINGS[0]}{more}", 24, (240, 190, 90), (960, 910),
                 bold=False, shadow=False)
        if not self.has_music:
            text(surf, "Файл музыки не найден в папке sounds", 28, (240, 120, 100), (960, 850),
                 bold=False, shadow=False)
        self.back.draw(surf)


# ---------------------------------------------------------------- достижения
class Achievements:
    def __init__(self, app):
        self.app = app
        self.back = BackButton(app, Settings, "НАЗАД")

    def handle(self, e):
        self.back.handle(e)

    def update(self, dt):
        pass

    def draw(self, surf):
        done = set(self.app.stats["achievements"])
        text(surf, "ДОСТИЖЕНИЯ", 64, WHITE, (960, 80))
        text(surf, f"Выполнено: {len(done & set(ACHIEVEMENTS))} из {len(ACHIEVEMENTS)}", 36, GOLD, (960, 150))
        for i, (aid, (name, desc)) in enumerate(ACHIEVEMENTS.items()):
            y = 210 + i * 215
            ok = aid in done
            panel(surf, (360, y, 1200, 185), (0, 0, 0, 150), 20,
                  (60, 230, 110, 255) if ok else (255, 255, 255, 110), 4 if ok else 2)
            cx, cy = 470, y + 92
            pygame.draw.circle(surf, GOLD if ok else GRAY, (sc(cx), sc(cy)), sc(55))
            pygame.draw.circle(surf, WHITE, (sc(cx), sc(cy)), sc(55), 3)
            draw_star(surf, (cx, cy), 36, WHITE if ok else (60, 68, 76))
            text(surf, name, 44, WHITE if ok else (200, 210, 205), (570, y + 52), "midleft")
            for j, ln in enumerate(wrap(desc, 30, 820)):
                text(surf, ln, 30, (220, 235, 228), (570, y + 108 + j * 36), "midleft",
                     bold=False, shadow=False)
            draw_coin(surf, (1420, y + 62), 28)
            text(surf, f"+{ACH_REWARD}", 44, GOLD, (1462, y + 62), "midleft")
            if ok:
                text(surf, "ВЫПОЛНЕНО", 28, (60, 230, 110), (1440, y + 130))
            else:
                text(surf, "НЕ ВЫПОЛНЕНО", 26, (170, 180, 175), (1440, y + 130))
        self.back.draw(surf)


# ---------------------------------------------------------------- статистика
class Stats:
    def __init__(self, app):
        self.app = app
        self.back = BackButton(app)

    def handle(self, e):
        self.back.handle(e)

    def update(self, dt):
        pass

    def draw(self, surf):
        text(surf, "СТАТИСТИКА", 64, WHITE, (960, 80))
        st = self.app.stats
        cards = [("Забито пенальти", str(st["penalties_scored"]), GREEN),
                 ("Отбито пенальти", str(st["penalties_saved"]), (190, 70, 110)),
                 ("Проведено матчей", str(st["matches"]), BLUE),
                 ("Пройдено уровней викторины", f"{st['quiz_levels']} / {len(QUIZ)}", PURPLE),
                 ("Выбрано сравнений", str(st["comparisons"]), (210, 110, 30)),
                 ("Монеты", str(st["coins"]), (185, 130, 20))]
        for i, (label, val, col) in enumerate(cards):
            row, cl = divmod(i, 2)
            x = 610 if (i == len(cards) - 1 and len(cards) % 2 == 1) else 200 + cl * 820
            rd = pygame.Rect(x, 160 + row * 290, 700, 260)
            panel(surf, rd, (0, 0, 0, 90), 18)
            panel(surf, rd, col + (225,), 18, (255, 255, 255, 140), 2)
            if label == "Монеты":
                draw_coin(surf, (rd.x + 110, rd.centery - 25), 52)
            text(surf, val, 130, WHITE, (rd.centerx, rd.centery - 25))
            text(surf, label, 36, (235, 245, 240), (rd.centerx, rd.bottom - 50))
        self.back.draw(surf)


# ---------------------------------------------------------------- main
def warmup(app):
    """Заранее создаёт шрифты, тексты и панели всех экранов.
    Раньше всё это создавалось в момент нажатия кнопки -> просадка FPS при входе."""
    tmp = pygame.Surface((W, H))

    def d(scene):
        scene.draw(tmp)

    d(Menu(app))
    d(Stats(app))
    st_ = Settings(app)
    old_music = app.stats["music_on"]
    for flag in (True, False):
        app.stats["music_on"] = flag
        d(st_)
    app.stats["music_on"] = old_music
    _render_text_cached("Файл музыки не найден в папке sounds", 28, (240, 120, 100), False, False)
    ac = Achievements(app)
    old_ach = list(app.stats["achievements"])
    app.stats["achievements"] = []
    d(ac)
    app.stats["achievements"] = list(ACHIEVEMENTS)
    d(ac)
    app.stats["achievements"] = old_ach
    panel(tmp, (560, 20, 800, 100), (0, 0, 0, 215), 20, (*GOLD, 255), 4)
    _render_text_cached("ДОСТИЖЕНИЕ ПОЛУЧЕНО!", 30, GOLD, True, False)
    for nm, _ in ACHIEVEMENTS.values():
        _render_text_cached(nm, 40, WHITE, True, True)
    sh = Shop(app)
    old = app.stats["last_daily"]
    d(sh)                                         # бонус готов
    app.stats["last_daily"] = time.time()
    d(sh)                                         # идёт таймер
    app.stats["last_daily"] = old

    p = Penalty(app)
    d(p)                                          # экран выбора роли
    for role in ("shooter", "keeper"):
        p.role = role
        p.phase, p.choice, p.keeper, p.t = "choose", None, None, 0.0
        d(p)
        p.choice, p.keeper, p.t = 0, 1, 0.5
        for ph in ("anim", "result"):
            p.phase = ph
            d(p)
        p.keeper = 0                              # «вратарь спас» / «отбил»
        d(p)
        p.phase = "final"
        for res in ([True] * 5, [True] * 3 + [False] * 2, [False] * 5):
            p.results = res
            d(p)
    pygame.event.pump()

    m = Match(app)
    d(m)                                          # списки лиг
    for name, _ in TEAMS[:60]:
        _render_text_cached(name, 36, WHITE, True, True)
    _render_text_cached("Выбери команду", 30, (150, 165, 158), True, True)
    for li, (_, teams) in enumerate(LEAGUES[:12]):    # строки команд каждой лиги в трёх вариантах
        m.view = [li, li]
        m.chosen = [(li, 0), (li, 1) if len(teams) > 1 else None]
        d(m)
        for ti, (tname, rating) in enumerate(teams[:40]):
            for variant in ("normal", "selected", "disabled"):
                m._row(("T", tname, rating, variant))
    li1 = 1 if len(LEAGUES) > 1 else 0
    m.view = [0, li1]
    m.chosen = [(0, 0), (li1, 0 if li1 else 1)]
    m.events = [(1, 0), (2, 1)]
    for st, mn in (("run", 5.0), ("done", 90)):
        m.state, m.minute = st, mn
        d(m)
    pygame.event.pump()

    for lvl in range(min(len(QUIZ), 15)):
        q = Quiz(app, lvl)
        d(q)
        q.picked = q.correct
        d(q)
        q.picked = (q.correct + 1) % 3
        d(q)
        q.win, q.picked = True, q.correct
        d(q)
    pygame.event.pump()

    c = Compare(app)
    for pair in PAIRS[:20]:
        c.cur = pair
        c.pick = None
        d(c)
        c.pick = 0
        d(c)
    pygame.event.pump()

    for n in (1, 2, 3):
        _render_text_cached(f"+{n}", 56, GOLD, True, True)
    for s_ in ("FPS 60", "FPS 30"):
        _render_text_cached(s_, 22, (180, 255, 200), False, False)


def main():
    app = App()
    screen.fill(DARK)
    text(screen, "ЗАГРУЗКА...", 60, WHITE, (960, 540))
    pygame.display.flip()
    warmup(app)
    music_set(app.stats["music_on"])
    app.fade = FADE_START if FADE else 0
    clock.tick()          # сбрасываем таймер после прогрева
    while True:
        raw_ms = clock.tick(60)
        dt = min(raw_ms / 1000, 0.05)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                quit_game()
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                if isinstance(app.scene, Menu):
                    quit_game()
                else:
                    app.go(Menu(app))
                continue
            app.scene.handle(e)
        app.scene.update(dt)
        screen.blit(BG, (0, 0))
        draw_particles(screen, dt)
        app.scene.draw(screen)
        if app.toast_t > 0:
            app.toast_t = max(0.0, app.toast_t - dt)
            rise = (1.5 - app.toast_t) * 25
            draw_coin(screen, (1600, 75 - rise), 34)
            text(screen, f"+{app.toast_n}", 56, GOLD, (1660, 75 - rise), "midleft")
        if app.ach_t > 0:
            app.ach_t = max(0.0, app.ach_t - dt)
            panel(screen, (560, 20, 800, 100), (0, 0, 0, 215), 20, (*GOLD, 255), 4)
            text(screen, "ДОСТИЖЕНИЕ ПОЛУЧЕНО!", 30, GOLD, (960, 50), shadow=False)
            text(screen, app.ach_name, 40, WHITE, (960, 92))
        if app.fade > 0:
            if raw_ms > 40:
                app.fade = 0          # кадр долгий (слабое устройство) — пропускаем затемнение
            else:
                FADE_SURF.set_alpha(int(app.fade))
                screen.blit(FADE_SURF, (0, 0))
                app.fade = max(0, app.fade - FADE_SPEED * dt)
        if SHOW_FPS:
            text(screen, f"FPS {int(clock.get_fps())}", 22, (180, 255, 200),
                 (1920 - 90, 1080 - 25), bold=False, shadow=False)
        pygame.display.flip()


if __name__ == "__main__":
    main()