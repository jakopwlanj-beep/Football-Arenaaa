# Football Arena: сборка APK через GitHub Actions

Всё уже настроено: buildozer.spec, шрифт с кириллицей (fonts/), workflow (.github/workflows/build.yml).

## Вариант 1. Через Termux и git (удобнее всего с телефона)

В обычном Termux (НЕ внутри Ubuntu; если ты в Ubuntu, набери `exit`):

    pkg install -y git unzip
    termux-setup-storage
    unzip ~/storage/downloads/FOMC_android.zip -d ~
    cd ~/FOMC_android
    git config --global user.name "твоё имя"
    git config --global user.email "твоя@почта"
    git init -b main
    git add .
    git commit -m "Football Arena"
    git remote add origin https://github.com/ЛОГИН/ИМЯ_РЕПО.git
    git push -u origin main

При push спросит логин (твой логин GitHub) и пароль. В поле пароля вставь токен, не пароль от аккаунта.

Токен: GitHub -> Settings -> Developer settings -> Personal access tokens -> Tokens (classic) -> Generate new token (classic). Отметь галочки `repo` и `workflow` (без workflow файл сборки не загрузится).

Репозиторий создай заранее на github.com: New repository, пустой, без README.

## Вариант 2. Через сайт GitHub (с компьютера)

Распакуй архив, на странице репозитория: Add file -> Upload files, перетащи ВСЁ содержимое папки FOMC_android, включая скрытую папку .github.

## Получение APK

1. Репозиторий -> вкладка Actions -> запуск "Build APK" (стартует сам после push, либо Run workflow).
2. Первая сборка идёт 15-30 минут. Зелёная галочка = готово.
3. Открой завершённый запуск -> внизу Artifacts -> FootballArena-apk -> скачай (это zip, внутри .apk).
4. Распакуй, установи APK (разреши установку из неизвестных источников).

## Если сборка красная

Открой запуск -> шаг "Build with Buildozer" -> промотай лог вверх до первой строки с error и пришли её.
